package pl.kurs.pracownik.firma.model;

public enum Sex {
    MALE, FEMALE;
}
