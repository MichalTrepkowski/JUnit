package pl.kurs.pracownik.firma.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Employee extends Person {
    private double salary;
    private int seniority;
    private double bonus;
    private Position position;

    private static List<Employee> extent = new ArrayList<>();

    private List<Company> companies = new ArrayList<>();

    private List<Branch> branches = new ArrayList<>();

    public Employee(String name, String surname, LocalDate birthDate, Sex sex, double salary, Position position, int seniority) {
        super(name, surname, birthDate, sex);
        this.salary = salary;
        this.position = position;
        this.seniority = seniority;
        bonus = countBonus();
    }

    public double countBonus() {
        return 200 * seniority;
    }

    public double getSalary() {
        return salary;
    }

    public int getSeniority() {
        return seniority;
    }

    public double getBonus() {
        return bonus;
    }

    public Position getPosition() {
        return position;
    }

    public static List<Employee> getExtent() {
        return extent;
    }

    public List<Company> getCompanies() {
        return companies;
    }

    public List<Branch> getBranches() {
        return branches;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Employee)) return false;
        Employee employee = (Employee) o;
        return Double.compare(employee.getSalary(), getSalary()) == 0 && getSeniority() == employee.getSeniority() && getPosition() == employee.getPosition() && Objects.equals(getCompanies(), employee.getCompanies()) && Objects.equals(getBranches(), employee.getBranches());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getSalary(), getSeniority(), getPosition(), getCompanies(), getBranches());
    }

    @Override
    public String toString() {
        return "Employee{" +
                "salary=" + salary +
                ", seniority=" + seniority +
                ", bonus=" + bonus +
                ", position=" + position +
                ", companies=" + companies +
                ", branches=" + branches +
                '}';
    }
}
