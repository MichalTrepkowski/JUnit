package pl.kurs;

public class Main {
}
