package pl.kurs.pracownik.firma.model;

public enum Position {
    BOSS, MANAGEMENT, WORKER;
}
